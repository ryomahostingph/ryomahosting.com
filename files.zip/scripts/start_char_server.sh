#!/bin/sh
cd /home/rathena/Desktop/rAthena
./char-server
