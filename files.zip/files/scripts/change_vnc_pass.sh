#!/bin/sh
RYOMA_DIR=/usr/share/ryoma
xterm -title "Change VNC Password" -bg black -fg white -hold -e sh $RYOMA_DIR/scripts/change_vnc_pass_script.sh &