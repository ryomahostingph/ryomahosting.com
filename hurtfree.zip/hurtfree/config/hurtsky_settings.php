<?php

$hurtsky = array(
	'yourServerName'				=> 'Hurtsky',									//this name maybe will be use on top and footer
	'newsTitleLimit'				=> 10,											//this will limit character/letter in title of RSS
	'newsContentLimit'				=> 20,											//this will limit character/letter in content of RSS
	$showcaseImages = array(
		'showcase.png',																//add name of image here
		'update.jpg',
	),
	'enableSocialNetworkLink'		=> true,										//disable this will remove the get connected section
	'enableFacebookIcon'			=> true,
	'facebookLink'					=> 'https://hurtsky.com/FluxCP',
	'enableDiscordIcon'				=> true,
	'discordInviteLink'				=> 'https://hurtsky.com/FluxCP',
	'enableTwitterIcon'				=> true,
	'twitterLink'					=> 'https://hurtsky.com/FluxCP',
	'footerCopyrightTrademarkLable'	=> 'All trademarks referenced herein are the properties of their respective owners',
	'footerCopyrightInitialDate'	=> 2017,
);